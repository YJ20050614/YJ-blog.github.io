package com.ld.poetry.im.http.service;

import com.ld.poetry.im.http.entity.ImChatGroupUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 聊天群成员 服务类
 * </p>
 *
 * @author sara
 * @since 2021-12-02
 */
public interface ImChatGroupUserService extends IService<ImChatGroupUser> {

}
