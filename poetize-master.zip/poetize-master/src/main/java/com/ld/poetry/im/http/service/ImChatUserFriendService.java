package com.ld.poetry.im.http.service;

import com.ld.poetry.im.http.entity.ImChatUserFriend;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 好友 服务类
 * </p>
 *
 * @author sara
 * @since 2021-12-02
 */
public interface ImChatUserFriendService extends IService<ImChatUserFriend> {

}
